package com.example.calendar.controller;

import com.example.calendar.dto.ScheduleForm;
import com.example.calendar.entity.Schedule;
import com.example.calendar.repository.ScheduleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

@Controller
@Slf4j
public class ScheduleController {

    @Autowired
    private ScheduleRepository scheduleRepository;

    @GetMapping("/schedules/calendar")
    public String calendar(
            @RequestParam(required = false)
            @DateTimeFormat(pattern = "yyyy-MM") YearMonth month,
            Model model) {

        YearMonth currentMonth = (month != null) ? month : YearMonth.now();

        LocalDate firstDay = currentMonth.atDay(1);
        int dayOfWeekIndex = firstDay.getDayOfWeek().getValue() % 7;
        LocalDate start = firstDay.minusDays(dayOfWeekIndex);
        LocalDate end = start.plusDays(41);

        Map<LocalDate, List<Schedule>> scheduleMap = new HashMap<>();
        for (Schedule s : scheduleRepository.findAll()) {
            if (s.getRepeatIntervalDays() == null || s.getRepeatStartDate() == null || s.getRepeatEndDate() == null) {
                scheduleMap.computeIfAbsent(s.getDate(), k -> new ArrayList<>()).add(s);
            } else {
                for (LocalDate d = s.getRepeatStartDate();
                     !d.isAfter(s.getRepeatEndDate());
                     d = d.plusDays(s.getRepeatIntervalDays())) {
                    scheduleMap.computeIfAbsent(d, k -> new ArrayList<>()).add(s);
                }
            }
        }

        List<List<Map<String, Object>>> calendarRows = new ArrayList<>();
        List<Map<String, Object>> week = new ArrayList<>();

        for (LocalDate date = start; !date.isAfter(end); date = date.plusDays(1)) {
            Map<String, Object> cell = new HashMap<>();
            cell.put("day", date.getDayOfMonth());
            cell.put("date", date);
            cell.put("schedules", scheduleMap.getOrDefault(date, new ArrayList<>()));
            cell.put("isToday", date.equals(LocalDate.now()));
            cell.put("isOtherMonth", !date.getMonth().equals(currentMonth.getMonth()));
            cell.put("isCurrentMonth", date.getMonth().equals(currentMonth.getMonth()));
            week.add(cell);

            if (week.size() == 7) {
                calendarRows.add(week);
                week = new ArrayList<>();
            }
        }

        List<Map<String, Object>> options = new ArrayList<>();
        for (int i = -12; i <= 12; i++) {
            YearMonth ym = currentMonth.plusMonths(i);
            Map<String, Object> opt = new HashMap<>();
            opt.put("value", ym.toString()); // yyyy-MM
            opt.put("label", ym.getYear() + "년 " + ym.getMonthValue() + "월");
            opt.put("selected", ym.equals(currentMonth));
            options.add(opt);
        }

        model.addAttribute("calendarRows", calendarRows);
        model.addAttribute("currentMonth", currentMonth);
        model.addAttribute("prevMonth", currentMonth.minusMonths(1));
        model.addAttribute("nextMonth", currentMonth.plusMonths(1));
        model.addAttribute("yearMonthOptions", options);

        return "schedules/calendar";
    }

    @GetMapping("/schedules/day")
    public String scheduleListByDate(@RequestParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                     Model model) {
        List<Schedule> schedules = scheduleRepository.findByDate(date);
        model.addAttribute("date", date);
        model.addAttribute("schedules", schedules);
        return "schedules/day";
    }

    @GetMapping("/schedules/new")
    public String newScheduleForm(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
                                  Model model) {
        ScheduleForm form = new ScheduleForm();
        form.setDate(date);
        model.addAttribute("form", form);
        return "schedules/new";
    }

    @PostMapping("/schedules/create")
    public String create(ScheduleForm form) {
        log.info(form.toString());
        Schedule schedule = new Schedule(
                null,
                form.getTitle(),
                form.getContent(),
                form.getDate(),
                form.getRepeatIntervalDays(),
                form.getRepeatStartDate(),
                form.getRepeatEndDate()
        );

        scheduleRepository.save(schedule);
        return "redirect:/schedules/day?date=" + form.getDate();
    }

    @GetMapping("/schedules/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
        Schedule schedule = scheduleRepository.findById(id).orElse(null);
        if (schedule == null) return "redirect:/schedules/calendar";

        ScheduleForm form = new ScheduleForm();
        form.setId(schedule.getId());
        form.setTitle(schedule.getTitle());
        form.setContent(schedule.getContent());
        form.setDate(schedule.getDate());
        form.setRepeatIntervalDays(schedule.getRepeatIntervalDays());
        form.setRepeatStartDate(schedule.getRepeatStartDate());
        form.setRepeatEndDate(schedule.getRepeatEndDate());

        model.addAttribute("schedule", form);
        return "schedules/edit";
    }



    @PostMapping("/schedules/update")
    public String update(ScheduleForm form) {
        Schedule schedule = scheduleRepository.findById(form.getId()).orElse(null);
        if (schedule != null) {
            schedule.setTitle(form.getTitle());
            schedule.setContent(form.getContent());
            schedule.setDate(form.getDate());
            schedule.setRepeatIntervalDays(form.getRepeatIntervalDays());
            schedule.setRepeatStartDate(form.getRepeatStartDate());
            schedule.setRepeatEndDate(form.getRepeatEndDate());
            scheduleRepository.save(schedule);
        }
        return "redirect:/schedules/day?date=" + form.getDate();
    }


    @GetMapping("/schedules/{id}/delete")
    public String delete(@PathVariable Long id) {
        Schedule schedule = scheduleRepository.findById(id).orElse(null);
        if (schedule != null) {
            LocalDate date = schedule.getDate();
            scheduleRepository.deleteById(id);
            return "redirect:/schedules/day?date=" + date;
        }
        return "redirect:/schedules/calendar";
    }
}