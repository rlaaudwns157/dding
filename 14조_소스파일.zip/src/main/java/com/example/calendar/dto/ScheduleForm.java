// ScheduleForm.java (수정본)
package com.example.calendar.dto;

import lombok.*;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class ScheduleForm {
    private Long id;
    private String title;
    private String content;
    private LocalDate date;
    private Integer repeatIntervalDays;
    private LocalDate repeatStartDate;
    private LocalDate repeatEndDate;
}
