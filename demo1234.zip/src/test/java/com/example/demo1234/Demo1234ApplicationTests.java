package com.example.demo1234;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1234ApplicationTests {

	@Test
	void contextLoads() {
	}

}
