package com.example.demo1234.controller;

import com.example.demo1234.dto.ArticleDto;
import com.example.demo1234.dto.ArticleForm;
import com.example.demo1234.service.ArticleService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



    @RestController
    @RequestMapping("/api/articles")
    public class ArticleAPIController {

        private final ArticleService articleService;

        public ArticleAPIController(@Qualifier("dbArticleService") ArticleService articleService) {
            this.articleService = articleService;
        }

        @GetMapping
        public List<ArticleDto> list() {
            return articleService.getAll();
        }

        @GetMapping("/{id}")
        public ArticleDto getOne(@PathVariable("id") Long id) {
            return articleService.getOne(id);
        }

        @PostMapping
        public ArticleDto create(@RequestBody ArticleForm articleForm) throws Exception {
            ArticleDto saved = articleService.create(articleForm);

            return saved;
        }

        @PatchMapping("/{id}")
        public ResponseEntity<ArticleDto> update(@PathVariable("id") Long id, @RequestBody ArticleForm articleForm) {
            ArticleDto updated = articleService.update(id, articleForm);

            return (updated != null) ?
                    ResponseEntity.ok(updated) :
                    ResponseEntity.badRequest().build();
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<ArticleDto> delete(@PathVariable("id") Long id) {
            ArticleDto deleted = articleService.delete(id);
            return (deleted != null) ?
                    ResponseEntity.ok(deleted) :
                    ResponseEntity.badRequest().build();
        }

        //http://localhost:8080/api/articles/search?keyword=spring
        @GetMapping("/search")
        public List<ArticleDto> searchArticles(@RequestParam("keyword") String keyword) {
            return articleService.searchByTitle(keyword);
        }
    }
}
