package com.example.demo1234.controller;

import com.example.demo1234.dto.ArticleForm;
import com.example.demo1234.entity.Article;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.List;

public class ArticleAPIController2 {

    @PostMapping("/transaction-test")
    public ResponseEntity<List<Article>> transactionTest(
            @RequestBody List<ArticleForm> articleForms
    ){
        List<Article> createdList = articleService.createArticles(articleForms);

        return (createdList != null) ?
                ResponseEntity.ok().body(createdList) : ResponseEntity.badRequest().build();
    }

    @Override
    public List<Article> createArticles(List<ArticleForm> articleFormList) {

        List<Article> articles = new ArrayList<>();

        for(ArticleForm articleForm : articleFormList){
            articles.add(articleForm.toEntity());
        }

        List<Article> updateList = articleRepository.saveAll(articles);

        return updateList;
    }
}
