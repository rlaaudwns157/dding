package com.example.demo1234.dto;

import com.example.demo1234.entity.Article;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor @AllArgsConstructor @ToString
public class ArticleForm {
    private String title;
    private String content;

    public Article toEntity() {
        return new Article(this.title, this.content);
    }
}