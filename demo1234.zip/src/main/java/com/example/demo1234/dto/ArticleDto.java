package com.example.demo1234.dto;

import com.example.demo1234.entity.Article;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor @AllArgsConstructor @ToString
public class ArticleDto {

    private Long id;
    private String title;
    private String content;

    public ArticleDto(Article article) {
        this.id = article.getId();
        this.title = article.getTitle();
        this.content = article.getContent();
    }

    public Article toEntity() {
        return new Article(this);
    }
}
