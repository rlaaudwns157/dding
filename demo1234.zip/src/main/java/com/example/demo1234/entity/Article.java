package com.example.demo1234.entity;

import com.example.demo1234.dto.ArticleDto;
import com.fasterxml.jackson.annotation.JsonTypeId;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class Article {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String content;

    public Article(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public Article(ArticleDto articleDto) {
        this.id = articleDto.getId();
        this.title = articleDto.getTitle();
        this.content = articleDto.getContent();
    }

    public ArticleDto toDto() {
        return new ArticleDto(this);
    }
}
