package com.example.demo1234.service;

import com.example.demo1234.dto.ArticleDto;
import com.example.demo1234.dto.ArticleForm;
import com.example.demo1234.entity.Article;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("memoryArticleService")
public class MemoryArticleService implements ArticleService{

    private final Map<Long, Article> store= new HashMap<>();
    private Long currentId = 1L;

    public MemoryArticleService() {

        create(new ArticleForm("테스트 글1", "테스트 내용 1"));
        create(new ArticleForm("스프링 부트", "자바 웹 프레임워크"));
    }

    @Override
    public List<ArticleDto> getAll() {
        return store.values()
                .stream()
                .map(article -> article.toDto())
                .toList();
    }

    @Override
    public ArticleDto getOne(Long id) {
        Article article = store.get(id);
        if(article == null) {
            throw new RuntimeException("글을 찾을 수 없습니다: " + id);
        }
        return article.toDto();
    }

    @Override
    public ArticleDto create(ArticleForm articleForm) {
        Long newId = currentId++;
        Article article =
                new Article(newId, articleForm.getTitle(), articleForm.getContent());
        store.put(newId, article);
        return article.toDto();
    }

    @Override
    public ArticleDto update(Long id, ArticleForm articleForm) {

        Article article = store.get(id);
        if( article == null) {
            throw new RuntimeException("수정할 글이 없습니다: " + id);
        }
        article.setTitle(articleForm.getTitle());
        article.setContent(articleForm.getContent());

        return article.toDto();
    }

    @Override
    public ArticleDto delete(Long id) {

        Article removed = store.remove(id);
        if(removed == null) {
            throw new RuntimeException("삭제할 글이 없습니다: " + id);
        }
        return removed.toDto();
    }

    @Override
    public List<ArticleDto> searchByTitle(String keyword) {

        return store.values()
                .stream()
                .filter(article -> article.getTitle().contains(keyword))
                .map(article -> article.toDto())
                .toList();

    }
}
