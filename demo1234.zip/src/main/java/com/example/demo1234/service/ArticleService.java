package com.example.demo1234.service;

import com.example.demo1234.dto.ArticleDto;
import com.example.demo1234.dto.ArticleForm;
import com.example.demo1234.entity.Article;

import java.util.List;

public interface ArticleService {

    List<ArticleDto> getAll();

    ArticleDto getOne(Long id);

    ArticleDto create(ArticleForm articleForm);

    ArticleDto update(Long id, ArticleForm articleForm);

    ArticleDto delete(Long id);

    List<ArticleDto> searchByTitle(String keyword);
}
