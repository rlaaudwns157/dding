package com.example.demo1234.service;

import com.example.demo1234.dto.ArticleDto;
import com.example.demo1234.dto.ArticleForm;
import com.example.demo1234.entity.Article;
import com.example.demo1234.repository.ArticleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service("dbArticleService")
public class DBArticleService implements ArticleService{

    private final ArticleRepository articleRepository;
    public DBArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    @Override
    public List<ArticleDto> getAll() {
        return articleRepository.findAll().stream()
                .map(ArticleDto::new)
                .collect(Collectors.toList());
    }

    @Override
    public ArticleDto getOne(Long id) {
        Article article = articleRepository.findById(id)
                .orElseThrow(
                        () -> new IllegalArgumentException("Article is not found: " + id));
        return article.toDto();
    }

    @Override
    public ArticleDto create(ArticleForm articleForm) {
        if(articleForm.getTitle().isEmpty() )
            throw new IllegalArgumentException("제목은 필수입니다.");

        Article article = articleForm.toEntity();
        Article saved = articleRepository.save(article);

        return saved.toDto();
    }

    @Override
    @Transactional
    public ArticleDto update(Long id, ArticleForm articleForm) {

        Article target = articleRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Article not found: " + id));

        target.setTitle(articleForm.getTitle());
        target.setContent(articleForm.getContent());

        return new ArticleDto(target);
    }

    @Override
    public ArticleDto delete(Long id) {
        Article target = articleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Article not found: " + id));
        articleRepository.delete(target);

        return new ArticleDto(target);
    }

    @Override
    public List<ArticleDto> searchByTitle(String keyword) {
        List<Article> articles =
                articleRepository.findByTitleContaining(keyword);

        return articles.stream().map(article -> article.toDto()).toList();
    }
}
